import request from "@/utils/request"

export function login(data) {
	return request({
		url: "/user/login",
		method: "post",
		data
	})
}

// export function getInfo(token) {
// 	return request({
// 		url: "/user/getusermessage",
// 		method: "get",
// 		params: { token }
// 	})
// }

export function logout() {
	return request({
		url: "/user/logout",
		method: "post"
	})
}

export function getUserHotOrder() {
	return request({
		url: "/user/getuserpaiming",
		method: "get"
	})
}

export function getUserBestVideo(data) {
	return request({
		url: "/user/searchuserbestvideo",
		method: "post",
		data
	})
}

export function createUser(data) {
	return request({
		url: "/user/zhuce",
		method: "post",
		data
	})
}

export function updateUserPassword(data) {
	return request({
		url: "/user/forgetpass",
		method: "post",
		data
	})
}

export function updateUserMessage(data) {
	return request({
		url: "/user/changeusermessage",
		method: "post",
		data
	})
}

