import request from "@/utils/request";

export function createComment(data) {
	return request({
		url: "/comment/addcomment",
		method: "get",
		params: { data }
	})
}

export function getCommentList(data) {
	return request({
		url: "/comment/reloadcomment",
		method: "get",
		params: { data }
	})
}