import request from "@/utils/request";

export function uploadImg(data) {
	return request({
		url: "/upload/uploadimg",
		method: "post",
		data
	})
}

export function uploadVideo(data) {
	return request({
		url: "/upload/uploadvideo",
		method: "post",
		data
	})
}
