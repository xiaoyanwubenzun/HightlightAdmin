import request from "@/utils/request";

export function uploadImg(data) {
	return request({
		url: "/upload/uploadimg",
		method: "post",
		// headers: {
		// 	"Content-Type": "multipart/form-data"
		// },
		data
	})
}

export function uploadVideo(data) {
	return request({
		url: "/upload/uploadvideo",
		method: "post",
		// headers: {
		// 	"Content-Type": "multipart/form-data"
		// },
		data
	})
}
