import request from "@/utils/request";
// import { axios, CancelToken, source } from "@/utils/commonaxios"

export function getVideoList(data) {
	return request({
		url: "/video/search",
		method: "post",
		data
	})
}

export function getUserVideoList(data) {
	return request({
		url: "/video/myhightlightsearch",
		method: "get",
		params: { data }
	})
}

export function getHottestVideoData() {
	return request({
		url: "/video/searchbestvideo",
		method: "get"
	})
}

export function getVideoData(data) {
	return request({
		url: "/video/getvideomessage",
		method: "get",
		params: { data }
	})
}

export function updateVideoPopularCount(data) {
	return request({
		url: "/video/addlikecount",
		method: "get",
		params: { data }
	})
}

export function createVideoArticle(data) {
	return request({
		url: "/video/uploadhightlight",
		method: "post",
		data
	})
}

// source.cancel("asdfdsgfghgjghjjk")