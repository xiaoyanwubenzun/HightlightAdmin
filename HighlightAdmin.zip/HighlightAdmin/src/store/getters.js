const getters = {
    token: state => state.user.token,
    avatar: state => state.user.avatar,
    name: state => state.user.name,
    introduction: state => state.user.introduction,
    roles: state => state.user.roles,
	backgroundStyle: state => state.user.backgroundStyle,
	user_info: state => state.user.user_info,
    errorLogs: state => state.errorLog.logs
}
export default getters
