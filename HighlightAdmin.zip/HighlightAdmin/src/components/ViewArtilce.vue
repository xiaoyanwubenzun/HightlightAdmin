<template>
	<div>

	</div>
</template>

<script>
	export default {
		components: {},
		data() {
			return {};
		},
		watch: {},
		computed: {},
		methods: {},
		beforeCreated() {},
		created() {},
		beforeMounted() {},
		mounted() {},
		beforeUpdated() {},
		updated() {},
		beforeDestroy() {},
		destroyed() {},
	};
</script>

<style lang="scss" scoped></style>