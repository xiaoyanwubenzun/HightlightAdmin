<template>
    <div>
<!--        <HighlightHeader @send="getUserInfo" class="uheader"></HighlightHeader>-->
        <div class="userinfo" :style="backgroundStyle">
            <div class="mymessage">
                <div class="usermessagehead">
                    <div v-if="user_info.user_name" class="whosmessage">
<!--                        <img-->
<!--                                class="whosuserimg"-->
<!--                                :src="user_info.user_img"-->
<!--                                alt="图片加载中"-->
<!--                        />-->
<!--                        <span class="whosname">{{ user_info.user_name }}</span>-->
<!--                        <i class="whosgender"><img :src="user_info.gender==='0'?'../../img/icons/wan_sex_unknow.png':(user_info.gender==='1'?'../../img/icons/wan_sex_m.png':'../../img/icons/wan_sex_w.png')" alt="图片加载中"-->
<!--                        /></i>-->
<!--                        <i class="whosage"><span>{{ user_info.user_age }}</span></i>-->
                        <span style="color: #559ad5;font-size: 16px;position: absolute;right: 25%;top: 30%;">
                            <el-tooltip
                                    class="item"
                                    effect="dark"
                                    content="修改"
                                    placement="top"
                            >
                              <i class="el-icon-edit-outline"></i>
                            </el-tooltip>
                        </span>
                        <span class="zonghepaiming">本站贡献排名：{{ user_info.ranking }}</span>
                        <div style="display: inline-block">
                            <img class="img-head" :src="user_info.user_img" alt=""/>
                        </div>
                        <div style="display: inline-block;color: cornflowerblue;">
                            <span class="user-message-span-name">{{ user_info.user_name }}</span>
                            <span class="user-message-span-else">
                                <span>
                                    <img :src="user_info.gender==='0'?'../../img/icons/wan_sex_unknow.png':(user_info.gender==='1'?'../../img/icons/wan_sex_m.png':'../../img/icons/wan_sex_w.png')" alt="" width="13" height="13"/>
                                </span>
                                <span style="color: #ffd048">{{user_info.user_age}}</span>
                            </span>
                        </div>
                    </div>
                    <div v-if="user_info.user_name" class="user-personality-message">
                        <div class="clear-float">
                            <span style="color: #559ad5;font-size: 14px;padding-left: 20px">喜欢：<span style="color: #000">{{ user_info.user_game_like?user_info.user_game_like:"太懒了，没有填写。" }}</span></span>
                            <span style="color: #559ad5;font-size: 14px;padding-left: 20px">签名：<span style="color: #000">{{ user_info.user_sign?user_info.user_sign:"太懒了，没有填写。" }}</span></span>
                            <span style="color: #559ad5;font-size: 14px;padding-left: 20px">电话：<span style="color: #000">{{ user_info.user_phone?user_info.user_phone:"太懒了，没有填写。" }}</span></span>
                            <span style="color: #559ad5;font-size: 14px;padding-left: 20px">星座：<span style="color: #000">{{ format_consttel }}</span></span>
                            <span style="color: #559ad5;font-size: 14px;padding-left: 20px">邮箱：<span style="color: #000">{{ user_info.user_email?user_info.user_email:"太懒了，没有填写。" }}</span></span>
                        </div>
                        <ul class="clear-float">
                            <li>
                                <i class="el-icon-video-camera"></i><span>发布集锦：<i>{{ user_info.vnum }}</i></span>
                            </li>
                            <li>
                                <i class="el-icon-star-off"></i><span>获得点赞：<i>{{ user_info.likenum }}</i></span>
                            </li>
                            <li>
                                <i class="el-icon-chat-dot-square"></i><span>评论总数：<i>{{ user_info.commentnum }}</i></span>
                            </li>
                            <li>
                                <i class="el-icon-view"></i><span>观看总数：<i>{{ user_info.wnum }}</i></span>
                            </li>
                        </ul>
                    </div>
                </div>
<!--                <div style="width: 80%;margin: 10px auto 0 auto;height: 100px">-->
<!--                    <div class="userimg clear-float">-->
<!--                        <img style="display: inline-block" :src="user_info.user_img" alt="头像加载失败" />-->
<!--                        <el-upload-->
<!--                                class="upload-demo"-->
<!--                                :show-file-list="false"-->
<!--                                :before-upload="beforeAvatarUpload"-->
<!--                                :auto-upload="false"-->
<!--                                action="#"-->
<!--                        >-->
<!--                            <el-button-->
<!--                                    class="uploaduserimgbtn"-->
<!--                                    size="small"-->
<!--                                    type="primary"-->
<!--                            >-->
<!--                                点击上传新头像-->
<!--                            </el-button>-->
<!--                            <el-button-->
<!--                                    class="uploaduserimgbtn"-->
<!--                                    size="small"-->
<!--                                    type="primary"-->
<!--                            >-->
<!--                                保存-->
<!--                            </el-button>-->
<!--                        </el-upload>-->
<!--                    </div>-->
<!--                </div>-->
<!--                <div class="userageandgender">-->
<!--                    <span>年龄：</span>-->
<!--                    <el-input-->
<!--                            type="text"-->
<!--                            size="small"-->
<!--                            placeholder="0~100岁"-->
<!--                            clearable-->
<!--                            v-model="user_info.user_age"-->
<!--                    ></el-input>-->
<!--                    <span>性别：</span>-->
<!--                    <el-radio-group v-model="user_info.user_gender">-->
<!--                        <el-radio :label="0">未知</el-radio>-->
<!--                        <el-radio :label="1">男</el-radio>-->
<!--                        <el-radio :label="2">女</el-radio>-->
<!--                    </el-radio-group>-->
<!--                </div>-->
<!--                <div class="usersign">-->
<!--                    <span>个性签名：</span>-->
<!--                    <el-input-->
<!--                            type="text"-->
<!--                            size="small"-->
<!--                            suffix-icon="el-icon-edit"-->
<!--                            maxlength="40"-->
<!--                            show-word-limit-->
<!--                            clearable-->
<!--                            v-model="user_info.user_sign"-->
<!--                    ></el-input>-->
<!--                </div>-->
<!--                <div class="usertel">-->
<!--                    <span>用户手机号：</span>-->
<!--                    <el-input-->
<!--                            type="text"-->
<!--                            size="small"-->
<!--                            suffix-icon="el-icon-phone-outline"-->
<!--                            clearable-->
<!--                            v-model="user_info.user_phone"-->
<!--                    ></el-input>-->
<!--                </div>-->
<!--                <div class="useremail">-->
<!--                    <span>用户邮箱：</span>-->
<!--                    <el-input-->
<!--                            type="email"-->
<!--                            size="small"-->
<!--                            suffix-icon="el-icon-message"-->
<!--                            clearable-->
<!--                            v-model="user_info.user_email"-->
<!--                    ></el-input>-->
<!--                </div>-->
<!--                <div class="userconsttell">-->
<!--                    <span>星座：</span>-->
<!--                    <el-select-->
<!--                            v-model="user_info.user_consttel"-->
<!--                            placeholder="请选择星座"-->
<!--                            size="small"-->
<!--                    >-->
<!--                        <el-option-->
<!--                                v-for="item in consttelloptions"-->
<!--                                :key="item.value"-->
<!--                                :label="item.label"-->
<!--                                :value="item.value"-->
<!--                        >-->
<!--                        </el-option>-->
<!--                    </el-select>-->
<!--                </div>-->
<!--                <div class="usergamelike">-->
<!--                    <span>喜欢的游戏：</span>-->
<!--                    <el-select-->
<!--                            v-model="user_info.user_game_value"-->
<!--                            multiple-->
<!--                            placeholder="选择喜欢的游戏"-->
<!--                            size="small"-->
<!--                    >-->
<!--                        <el-option-->
<!--                                v-for="item in gameoptions"-->
<!--                                :key="item.value"-->
<!--                                :label="item.label"-->
<!--                                :value="item.value"-->
<!--                        >-->
<!--                        </el-option>-->
<!--                    </el-select>-->
<!--                </div>-->
<!--                <div class="usermibao">-->
<!--                    <span>密保：</span>-->
<!--                    <el-input-->
<!--                            type="text"-->
<!--                            size="small"-->
<!--                            maxlength="10"-->
<!--                            show-word-limit-->
<!--                            clearable-->
<!--                            v-model="user_info.user_mibao"-->
<!--                    ></el-input>-->
<!--                </div>-->
<!--                <div class="tijiaobtn">-->
<!--                    <el-button-->
<!--                            type="primary"-->
<!--                            size="small"-->
<!--                            @click="confirmchangeusermessage()"-->
<!--                    >保存</el-button-->
<!--                    >-->
<!--                    <el-button-->
<!--                            type="info"-->
<!--                            size="small"-->
<!--                    >取消</el-button>-->
<!--                </div>-->

                <div class="user-uploadvideo">
                    <template v-if="video_list.length>0">
                        <div class="video-list">
                            <div
                                    v-for="item in video_list"
                                    :key="item.vid"
                                    class="containeachvideo"
                            >
                                <div class="eachvideo">
                                    <a
                                            class="v-lnk"
                                            :href="'/view-video?vid=' + item.vid"
                                    >
                                        <img
                                                :src="item.fengmian"
                                                width="200"
                                                height="150"
                                                alt="封面加载错误"
                                        />
                                        <div class="v-overlay"></div>
                                        <span class="v-icon"></span>
                                    </a>
                                    <div class="videomessage">
                                        <h3 class="videotitle">{{ item.vtitle }}</h3>
                                        <div class="videocontent">
                                            <p>
                                                {{
                                                item.vtext == ""
                                                ? "这位用户很懒，没有写文字内容哦"
                                                : item.vtext
                                                }}
                                            </p>
                                            <p
                                                    data-we-empty-p=""
                                                    style="text-align: center"
                                            ></p>
                                        </div>
                                        <div class="typeanduser">
                                            <div class="videotype">
                                                <i
                                                ><img
                                                        src="../../assets/index/game.png"
                                                        alt="图片加载失败"
                                                /></i>
                                                <span>{{ item.videotype }}</span>
                                            </div>
                                            <div class="videouser">
                                                <i
                                                ><img
                                                        src="../../assets/index/user.png"
                                                        alt="图片加载失败"
                                                /></i>
                                                <span>{{ item.username }}</span>
                                            </div>
                                        </div>
                                        <div class="sangezhibiao">
                                            <ul class="clear-float">
                                                <li>
                                                    <i class="el-icon-video-play"></i>
                                                    浏览：{{ item.watchnum }}
                                                </li>
                                                <li>
                                                    <i class="el-icon-star-off"></i>
                                                    获赞：{{ item.likecount }}
                                                </li>
                                                <li>
                                                    <i
                                                            class="el-icon-chat-dot-square"
                                                    ></i>
                                                    评论：{{ item.cnum }}
                                                </li>
                                                <li>
                                                    发布日期：{{
                                                    new Date(
                                                    item.createtime
                                                    ).toLocaleDateString()
                                                    }}
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="myhightlightsearch">
                            <input
                                    class="input"
                                    type="text"
                                    placeholder="搜索(标题关键字标题、内容、游戏类型、作者)"
                                    v-model="keyword"
                                    @keydown.enter="searchUserVideo()"
                            />
                        </div>
                        <el-pagination
                                background
                                layout="prev, pager, next"
                                :total="totalpage"
                                @current-change="currentChange"
                        >
                        </el-pagination>
                    </template>
                    <template v-else>
                        <span style="position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);color: #606266">未查询到内容</span>
                    </template>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import HighlightHeader from "@/components/HighlightHeader.vue";
    import { getUserRanking } from "@/api/user";
    import { getUserHighLight } from "@/api/video";
    import { deepClone } from "@/filters";
    import { uploadImg } from "@/api/upload";
    export default {
        name: "userMessage",
        components: { HighlightHeader },
        props: {
            userInfo: {
        		type: Object,
        		required: true
        	}
        },
        data() {
            return {
                backgroundStyle: "",
                consttelloptions: [
                    {
                        value: 1,
                        label: "水瓶座",
                    },
                    {
                        value: 2,
                        label: "双鱼座",
                    },
                    {
                        value: 3,
                        label: "白羊座",
                    },
                    {
                        value: 4,
                        label: "金牛座",
                    },
                    {
                        value: 5,
                        label: "双子座",
                    },
                    {
                        value: 6,
                        label: "巨蟹座",
                    },
                    {
                        value: 7,
                        label: "狮子座",
                    },
                    {
                        value: 8,
                        label: "处女座",
                    },
                    {
                        value: 9,
                        label: "天枰座",
                    },
                    {
                        value: 10,
                        label: "天蝎座",
                    },
                    {
                        value: 11,
                        label: "射手座",
                    },
                    {
                        value: 12,
                        label: "魔羯座",
                    },
                ],
                gameoptions: [
                    {
                        value: "英雄联盟",
                        label: "英雄联盟",
                    },
                    {
                        value: "穿越火线",
                        label: "穿越火线",
                    },
                    {
                        value: "绝地求生",
                        label: "绝地求生",
                    },
                ],
                user_info: this.userInfo,
                edit_user_data: {},
                totalpage: 1000,
                keyword: "",
                pagenum: 1,
                video_list: [],
            };
        },
        computed: {
            format_consttel(){
                return this.consttelloptions[Number(this.user_info.user_consttel)-1].label
            }
        },
        methods: {
            async getUsersMessage() {
                let res = await getUserRanking().then(res => res).catch((err) => {console.log(err)});
                this.searchUserVideo();
                if(res){
                    if(res.code===200){
                        let valid_ranking_user = [], user_list = [];
                        valid_ranking_user = res.data.userList.map(item => item.uid);
                        if(valid_ranking_user.indexOf(this.user_info.uid)>-1){
                            user_list = deepClone(res.data.userList);
                            user_list.forEach((item,index) => {
                                item.ranking = index + 1;
                                // switch (item.gender) {
                                //     case 0:
                                //         item.gender = "../../img/icons/wan_sex_unknow.png";
                                //         break;
                                //     case 1:
                                //         item.gender = "../../img/icons/wan_sex_m.png";
                                //         break;
                                //     case 2:
                                //         item.gender = "../../img/icons/wan_sex_w.png";
                                //         break;
                                //     default:
                                //         break;
                                // }
                            });
                            this.user_info = user_list.filter(item => item.uid === Number(this.user_info.uid))[0];
                            this.user_info = Object.assign({},this.$store.getters.user_info,this.user_info);
                            console.log(this.user_info);
                        } else {
                            this.user_info.wnum = 0;
                            this.user_info.likenum = 0;
                            this.user_info.commentnum = 0;
                            this.user_info.vnum = 0;
                            this.user_info.sums = 0;
                            this.user_info.ranking = "10000+";
                            this.user_info = Object.assign({},this.$store.getters.user_info,this.user_info);
                            this.$forceUpdate();
                            // switch (this.user_info.gender) {
                            //     case 0:
                            //         this.user_info.gender = "../../img/icons/wan_sex_unknow.png";
                            //         break;
                            //     case 1:
                            //         this.user_info.gender = "../../img/icons/wan_sex_m.png";
                            //         break;
                            //     case 2:
                            //         this.user_info.gender = "../../img/icons/wan_sex_w.png";
                            //         break;
                            //     default:
                            //         break;
                            // }
                            // console.log(this.user_info);
                        }
                    } else {
                        this.$message.error(res.message);
                    }
                }
            },
            async searchUserVideo() {
                let res = await getUserHighLight({ uid: this.$store.getters.user_info.uid, keyword: this.keyword, pagenum: this.pagenum }).then(res => res).catch((err) => {console.log(err)});
                if(res){
                    if(res.code===200){
                        this.video_list = deepClone(res.data.videoList);
                        this.totalpage = res.data.total;
                    } else {
                        this.$message.error(res.message);
                    }
                }
            },
            currentChange(val) {
                this.pagenum = val;
                this.searchUserVideo();
            },
            confirmchangeusermessage() {
                this.$confirm(
                    "确认修改您的个人信息, 是否继续?",
                    "个人信息修改提示",
                    {
                        confirmButtonText: "确定",
                        cancelButtonText: "取消",
                        type: "warning",
                    }
                )
                    .then(() => {
                        if (
                            !this.edit_user_data.user_img ||
                            !this.edit_user_data.user_age ||
                            !this.edit_user_data.user_sign ||
                            !this.edit_user_data.user_phone ||
                            !this.edit_user_data.user_email ||
                            !this.edit_user_data.verify
                        ) {
                            this.$message.warning("请完善个人资料");
                            return;
                        } else if (
                            !/^\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]*\.)+[A-Za-z]{2,14}$/.test(
                                this.useremail
                            )
                        ) {
                            this.$message.warning("邮箱格式不正确");
                            return;
                        } else if (
                            !/^((13\d|14[57]|15[^4,\D]|17[678]|18\d)\d{8}|170[059]\d{7})$/.test(
                                this.usertel
                            )
                        ) {
                            this.$message.warning("手机号格式不正确");
                            return;
                        }
                        switch (this.consttell) {
                            case "水瓶座":
                                this.consttell = 1;
                                break;
                            case "双鱼座":
                                this.consttell = 2;
                                break;
                            case "白羊座":
                                this.consttell = 3;
                                break;
                            case "金牛座":
                                this.consttell = 4;
                                break;
                            case "双子座":
                                this.consttell = 5;
                                break;
                            case "巨蟹座":
                                this.consttell = 6;
                                break;
                            case "狮子座":
                                this.consttell = 7;
                                break;
                            case "处女座":
                                this.consttell = 8;
                                break;
                            case "天枰座":
                                this.consttell = 9;
                                break;
                            case "天蝎座":
                                this.consttell = 10;
                                break;
                            case "射手座":
                                this.consttell = 11;
                                break;
                            case "魔羯座":
                                this.consttell = 12;
                                break;
                            default:
                                break;
                        }
                        this.changeusermessage();
                    })
                    .catch(() => {
                        this.$message({
                            type: "info",
                            message: "已取消修改",
                        });
                    });
            },
            // changeusermessage() {
            // 	this.axios
            // 		.post("/changeusermessage", {
            // 			uid: sessionStorage.getItem("who"),
            // 			userimg: this.userimg,
            // 			gender: this.usergender,
            // 			uage: this.userage,
            // 			usersign: this.usersign,
            // 			tel: this.usertel,
            // 			useremail: this.useremail,
            // 			consttell: this.consttell,
            // 			gamevalue: this.gamevalue.join(),
            // 			mibao: this.mibao,
            // 		})
            // 		.then((res) => {
            // 			if (res.data.code == 1) {
            // 				this.$message.success(res.data.Msg);
            // 				this.getusermessage();
            // 			} else {
            // 				this.$message.error(res.data.Msg);
            // 				this.getusermessage();
            // 			}
            // 		})
            // 		.catch((err) => {
            // 			console.log(err);
            // 		});
            // },
            // handleAvatarSuccess(res, file) {
            // 	this.user_info.userimg = res.data[0].url;
            // },
            beforeAvatarUpload(file) {
                // console.log(file);
                const isJPG = file.type === "image/jpeg";
                const isPNG = file.type === "image/png";
                const isLt10M = file.size / 1024 / 1024 < 10;
                if (!isJPG && !isPNG) {
                    this.$message.error("上传头像只能是 JPG、PNG 格式!");
                }
                if (!isLt10M) {
                    this.$message.error("上传头像不能超过 10MB!");
                }
                return isJPG || (isPNG && isLt10M);
            },
            // getUserInfo(res){
            //     // let res = await this.$store.dispatch("user/getInfo").then( res => res).catch((err) => {console.log(err);})
            //     // if(res){
            //     // 	if (res.code == 200) {
            //     // 		this.user_info = deepClone(this.$store.getters.user_info);
            //     // 		// console.log("sdfdfdsf");
            //     // 	}
            //     // }
            //     this.user_info = deepClone(res);
            // }
        },
        created() {
            // let guankanjijin = document.querySelector(".el-menu-item:nth-child(7)");
            // guankanjijin.className = "el-menu-item right is-active";
        },
        mounted() {
            // let guankanjijin = document.querySelector(".el-menu-item:nth-child(7)");
            // guankanjijin.className = "el-menu-item right is-active";
            this.$store.dispatch("common/setBgStyle");
            this.backgroundStyle = this.$store.getters.backgroundStyle;
            this.getUsersMessage();
            // console.log(this.userInfo);
            // this.getUserInfo();
        },
    };
</script>

<style lang="scss">
    .userinfo {
        height: 120vh;
        position: relative;
    }
    .uheader {
        position: fixed;
        z-index: 100;
    }
    .img-head {
        margin: 10px 0 0 10px;
        height: 50px;
        width: 50px;
        border-radius: 50%;
        object-fit: cover;
    }
    .user-message-span-name {
        width: auto;
        display: block;
        height: 30px;
        line-height: 30px;
        padding-left: 25px;
        white-space: nowrap;
        /*overflow: hidden;*/
        /*text-overflow: ellipsis;*/
    }
    .user-message-span-else {
        height: 30px;
        display: flex;
        justify-content: space-evenly;
        align-items: center;
    }
    .mymessage {
        display: inline-block;
        width: 90%;
        height: 80%;
        // padding-top: 5%;
        margin-top: 5%;
        margin-left: 50%;
        transform: translateX(-50%);
        border-radius: 10px;
        background-color: rgba(245, 222, 179, 0.7);
        .usermessagehead,
        .user-uploadvideo {
            border-radius: 5px;
            transition: all 0.2s ease-in-out;
            background-color: rgba(255, 255, 255, 0.7);
        }
        .usermessagehead:hover,.user-uploadvideo:hover {
            box-shadow: 5px 5px 7px rgba(71, 70, 70, 0.6);
        }
        .usermessagehead {
            height: 150px;
            width: 65vw;
            margin: 2rem auto 0 96px;
            .whosmessage {
                width: 100%;
                height: 50%;
                position: relative;
                /*.whosuserimg {*/
                /*    margin: 10px 0 0 10px;*/
                /*    height: 50px;*/
                /*    width: 50px;*/
                /*    border-radius: 50%;*/
                /*    object-fit: cover;*/
                /*}*/
                /*.whosgender img {*/
                /*    width: 15px;*/
                /*    height: 15px;*/
                /*    position: absolute;*/
                /*    top: 25%;*/
                /*    left: 25%;*/
                /*}*/
                /*.whosname {*/
                /*    position: absolute;*/
                /*    top: 15px;*/
                /*    left: 70px;*/
                /*    color: cornflowerblue;*/
                /*}*/
                /*.whosage span {*/
                /*    position: absolute;*/
                /*    top: 15px;*/
                /*    left: 28%;*/
                /*    font-style: normal;*/
                /*    color: darkorchid;*/
                /*}*/
                .zonghepaiming {
                    position: absolute;
                    right: 50px;
                    top: 20px;
                    font-size: 20px;
                    color: #f28123;
                }
            }
            .user-personality-message {
                /*.whossign {*/
                /*    margin-left: 65px;*/
                /*    color: chocolate;*/
                /*    font-size: 15px;*/
                /*}*/
                ul {
                    list-style: none;
                    color: #559ad5;
                    margin: 10px 0 0 10px;
                }
                ul li {
                    float: left;
                }
                ul li i {
                    vertical-align: bottom;
                    margin-right: 5px;
                }
                ul li span {
                    font-weight: normal;
                    font-size: 12px;
                }
                ul li span i {
                    font-style: normal;
                    font-weight: normal;
                    font-size: 13px;
                    color: #000;
                }
            }
        }
        .user-uploadvideo {
            height: 500px;
            width: 80vw;
            margin: 2rem auto 0 96px;
            position: relative;
            .video-list {
                width: 55rem;
                height: 25.625rem;
                overflow: hidden;
                overflow-x: scroll;
                overflow-y: unset;
                margin-left: calc(50% - 15%);
                transform: translateX(-50%);
                .containeachvideo {
                    width: 53.75rem;
                    margin: 1.25rem auto 0 auto;
                    position: relative;
                    .videomessage {
                        height: 9.375rem;
                        width: 37.5rem;
                        position: absolute;
                        background-color: rgba(250, 235, 215, 0.7);
                        border-radius: 0.625rem;
                        right: 0.625rem;
                        top: 0.625rem;
                        transition: all 0.2s ease-in-out;
                        .videotitle {
                            margin-top: 0.625rem;
                            text-align: center;
                            color: #409eff;
                        }
                        .videocontent {
                            width: 31.25rem;
                            height: 4.375rem;
                            margin-top: 1.25rem;
                            margin: 0 auto;
                        }
                        .videocontent p {
                            width: 13.125rem;
                            color: #559ad5;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                        }

                        .typeanduser .videotype i {
                            position: absolute;
                            bottom: 1.75rem;
                            left: 1.25rem;
                        }
                        .typeanduser .videotype span {
                            position: absolute;
                            bottom: 1.875rem;
                            left: 2.5rem;
                            font-size: 0.875rem;
                            color: #66c3ff;
                        }
                        .typeanduser .videouser i {
                            position: absolute;
                            bottom: 1.625rem;
                            right: 6.875rem;
                        }
                        .typeanduser .videouser span {
                            display: block;
                            width: 5.625rem;
                            height: 1.25rem;
                            text-align: left;
                            position: absolute;
                            bottom: 1.75rem;
                            right: 0.9375rem;
                            overflow: hidden;
                            white-space: nowrap;
                            text-overflow: ellipsis;
                            font-size: 0.875rem;
                            color: #66c3ff;
                        }
                        .sangezhibiao {
                            height: 1.875rem;
                            width: 37.5rem;
                            position: absolute;
                            bottom: 0;
                        }
                        .sangezhibiao ul {
                            list-style: none;
                        }
                        .sangezhibiao ul li {
                            color: #559ad5;
                            margin: 0 0.8125rem;
                            font-size: 0.8125rem;
                            float: right;
                            line-height: 1.875rem;
                        }
                        .sangezhibiao ul li:nth-child(4) {
                            color: #559ad5;
                            margin: 0 0.8125rem;
                            font-size: 0.8125rem;
                            float: left;
                            line-height: 1.875rem;
                        }
                    }
                    .videomessage:hover {
                        box-shadow: 0.3125rem 0.3125rem 0.4375rem
                        rgba(71, 70, 70, 0.6);
                    }
                }
                .eachvideo {
                    width: 12.5rem;
                    height: 9.375rem;
                    display: inline-block;
                    margin: 0.625rem;
                    .v-lnk {
                        position: relative;
                        display: block;
                        height: 9.375rem;
                        cursor: pointer;
                    }
                    @keyframes ani-ico {
                        from {
                            transform: scale(3);
                            opacity: 0;
                        }
                        to {
                            transform: scale(1);
                            opacity: 1;
                        }
                    }
                    .v-lnk:hover .v-overlay {
                        opacity: 1;
                        filter: alpha(opacity=100);
                        background-color: #53bcf6;
                        opacity: 0.7;
                        border-radius: 0.625rem;
                        filter: alpha(opacity=70);
                    }
                    .v-lnk:hover .v-icon {
                        animation: 0.2s linear 0s normal none ani-ico;
                        -webkit-animation: 0.2s linear 0s normal none ani-ico;
                        opacity: 1;
                    }
                    .v-overlay {
                        position: absolute;
                        top: 0;
                        left: 0;
                        width: 100%;
                        border-radius: 0.625rem;
                        background: rgba(84, 189, 247, 0.7);
                        filter: progid:DXImageTransform.Microsoft.gradient(enabled='true',startColorstr='#77df4e3a',endColorstr='#77df4e3a');
                        zoom: 1;
                        height: 9.375rem;
                        opacity: 0;
                        filter: alpha(opacity=0);
                        -webkit-transition: all 0.3s ease-in-out;
                        -moz-transition: all 0.3s ease-in-out;
                        transition: all 0.3s ease-in-out;
                    }
                    .v-icon {
                        width: 3.125rem;
                        height: 3.125rem;
                        background: url("../../assets/index/play.png") no-repeat;
                        background-size: cover;
                        position: absolute;
                        left: 4.6875rem;
                        top: 3.125rem;
                        opacity: 0;
                    }
                }
                .eachvideo img {
                    border-radius: 0.625rem;
                    object-fit: cover;
                }
            }
        }
        .myhightlightsearch {
            position: absolute;
            top: 50px;
            right: 0;
            text-align: center;
            width: 25vw;
            height: 50px;
            .input {
                width: 14.375rem;
                margin-right: 20px;
                max-width: 90%;
                outline: none;
                /* border: 1px solid rgba(255,255,255,0.3); */
                border: none;
                padding: 0.8125rem 0.9375rem;
                border-radius: 1.875rem;
                // color: rgba(255, 255, 255, 0.8);
                color: black;
                font-size: small;
                font-weight: normal;
                font-family: "Microsoft Yahei", sans-serif;
                text-align: center;
                background-color: rgba(255, 255, 255, 0.25);
                box-shadow: rgba(0, 0, 0, 0.2) 0 0 0.625rem;
                -webkit-backdrop-filter: blur(0.625rem);
                backdrop-filter: blur(0.625rem);
                transition: color 0.25s, background-color 0.25s, box-shadow 0.25s,
                left 0.25s, opacity 0.25s, top 0.25s, width 0.25s;
            }
            .input:hover {
                color: var(--txt-b-pure);
                background-color: rgba(255, 255, 255, 0.6);
                box-shadow: rgba(0, 0, 0, 0.3) 0 0 0.625rem;
                width: 25.125rem;
            }
        }
        .el-pagination {
            width: 55rem;
            white-space: nowrap;
            padding: 2px 5px;
            color: #303133;
            font-weight: 700;
            margin-top: 20px;
            text-align: center;
            margin-left: calc(50% - 15%);
            transform: translateX(-50%);
        }
        .userimg {
            text-align: left;
            img {
                width: 60px;
                height: 60px;
                border-radius: 50%;
                object-fit: cover;
            }
            .uploaduserimgbtn {
                margin-left: 100px;
                margin-top: 37px;
            }
        }
        .userageandgender {
            .el-input {
                width: 22%;
            }
        }
        .usersign,
        .usertel,
        .useremail,
        .usermibao {
            .el-input {
                width: 50%;
            }
        }
        .userconsttell {
            .el-select {
                width: 28%;
            }
        }
        .usergamelike {
            .el-select {
                width: 65%;
            }
        }
        .tijiaobtn {
            text-align: center;
            margin-top: 50px !important;
            margin-bottom: 40px;
            span {
                color: white !important;
            }
            .el-button {
                margin-right: 20px;
            }
        }
        .userageandgender,
        .usersign,
        .usertel,
        .useremail,
        .userconsttell,
        .usergamelike,
        .usermibao,
        .tijiaobtn {
            color: #606266;
            margin-top: 20px;
            span {
                vertical-align: bottom;
                color: #559ad5;
                margin-left: 40px;
            }
        }
        .tijiaobtn button span {
            margin-left: 0;
        }
        .usergamelike .el-select span {
            margin-left: 0;
        }
        .usersign .el-input span {
            margin-left: 0;
        }
        .userageandgender {
            white-space: nowrap;
            .el-radio-group {
                span {
                    margin-left: 0;
                }
            }
        }
        .userageandgender span:nth-child(3) {
            vertical-align: middle;
            margin-left: 20px;
        }
    }
</style>
