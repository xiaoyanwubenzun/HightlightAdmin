<template>
    <div>
        <userMessage></userMessage>
        <userVideo></userVideo>
    </div>
</template>

<script>
    import userMessage from "@/views/userMessage.vue";
    import userVideo from "@/views/userVideo.vue";
    export default {
        name: "index",
        components: { userMessage, userVideo}
    }
</script>

<style scoped>

</style>