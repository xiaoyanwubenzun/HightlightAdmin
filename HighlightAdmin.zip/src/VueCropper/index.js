import VueCropper from "vue-cropper";
// const VueCropper = {
// 	install: function (Vue) {
// 		Vue.use(vuecropper)
// 	}
// }

export default VueCropper;