import Vue from "vue"
import VueRouter from "vue-router"

Vue.use(VueRouter)

export const routes = [
	// {
	// 	path: "/hightlightheader",
	// 	name: "Hightlightheader",
	// 	component: () => import("@/components/Hightlightheader.vue"),
	// 	isMenu: false
	// },
	{
		path: "/",
		name: "login",
		component: () => import("@/views/login/login.vue"),
		meta: {
			name: "登录集锦系统",
		},
		isMenu: false
	},
	{
		path: "/logon",
		name: "logon",
		component: () => import("@/views/login/logon.vue"),
		meta: {
			name: "用户注册",
		},
		isMenu: false
	},
	{
		path: "/forget-password",
		name: "forgetPassword",
		component: () => import("@/views/login/forgetPassword.vue"),
		meta: {
			name: "忘记密码",
		},
		isMenu: false
	},

	{
		path: "/index",
		name: "index",
		component: () => import("@/views/index/index.vue"),
		meta: {
			name: "首页",
		},
		isMenu: true
	},
	{
		path: "/my-highlight",
		name: "myHighlight",
		component: () => import("@/views/userInfo/userVideo.vue"),
		meta: {
			name: "我的集锦",
		},
		isMenu: true
	},
	{
		path: "/upload-highlight",
		name: "uploadHighlight",
		component: () => import("@/views/publish/publishVideo.vue"),
		meta: {
			name: "上传新的集锦",
		},
		isMenu: true
	},
	{
		path: "/whole-highlight",
		name: "wholeHighlight",
		component: () => import("@/views/wholeHighlight/wholeHighlight.vue"),
		meta: {
			name: "大神们的集锦",
		},
		isMenu: true
	},
	{
		path: "/view-video",
		name: "viewVideo",
		component: () => import("@/views/viewVideo/viewVideo.vue"),
		meta: {
			name: "观看集锦",
		},
		isMenu: true,
		beforeEnter(to, from, next) {
			if (!to.query.vid) {
				alert("别乱来");
				router.push("/");
			} else {
				next();
			}
		}
	},
	{
		path: "/user-info",
		name: "userInfo",
		component: () => import("@/views/userInfo/userMessage.vue"),
		meta: {
			name: "个人信息",
		},
		isMenu: true
	},
]
// router.beforeEach((to, from, next) => {
//     // window.document.title = this.$route.meta.name;
//     // console.log(window);
//     // next();
// })

// router.beforeRouteEnter(to, from, next) {
//     window.document.title = this.$route.meta.name;
//     next();
// }

const router = new VueRouter({
	mode: "history",
	base: process.env.BASE_URL,
	routes
})

router.beforeEach((to, from, next) => {
	window.document.title = to.meta.name;
	// console.log(to.meta.name);
	// console.log(to);
	next();
})
export default router